<?php

/**
 * Fired during plugin activation
 *
 * @link       https://profiles.wordpress.org/iqbal1486/
 * @since      1.0.0
 *
 * @package    Gh_Hook_Commerce
 * @subpackage Gh_Hook_Commerce/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Gh_Hook_Commerce
 * @subpackage Gh_Hook_Commerce/includes
 * @author     Geekerhub <iahmed964@gmail.com>
 */
class Gh_Hook_Commerce_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$error = 'Please install and activate <b>WooCommerce</b> plugin.';
        if ( !class_exists( 'WooCommerce' ) ) {
           die( 'Plugin not activated: ' . $error );
        }
	}

}
