These images are required for jquery-ui
