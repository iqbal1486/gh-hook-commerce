ace.define("ace/snippets/livescript",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="livescript"});
                (function() {
                    ace.require(["ace/snippets/livescript"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            