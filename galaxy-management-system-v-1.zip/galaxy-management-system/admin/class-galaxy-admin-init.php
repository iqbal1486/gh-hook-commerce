<?php

// Preventing to direct access
defined( 'ABSPATH' ) OR die( 'Direct access not acceptable!' );

/**
 * Add plugin menus
 * @author WeCreativez
 * @since 1.2
 */
class GALAXY_Admin_Init {

    public function __construct() {
        $this->settings_api = new GALAXY_Admin_Settings_API;
        add_action( 'admin_init', array( $this, 'init_settings' ), 20 );
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
    }


    public function init_settings() {

        $sections_label = array();

        
        $sections_label[] =     array(
                                    'id'    => 'galaxy_basic_settings',
                                    'title' => __( 'Basic Settings', 'wc-galaxy' ),
                                );

        $sections_label[] =     array(
                                    'id'    => 'galaxy_how_to',
                                    'title' => __( 'How to Use', 'wc-galaxy' ),
                                    'custom_page' => GALAXY_PLUGIN_PATH . 'admin/views/how-to-use.php',
                                );

        
        $sections = apply_filters( 'galaxy_admin_setting_sections', $sections_label );

        $fields = apply_filters( 'galaxy_admin_setting_fields', array(
            'galaxy_basic_settings'        => include_once GALAXY_PLUGIN_PATH . 'admin/views/admin-basic-settings.php',
        ) );

        $this->settings_api->set_sections( $sections );
        $this->settings_api->set_fields( $fields );
        $this->settings_api->admin_init();
    }

    /**
     * Add plugin setting menu on WordPress admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            esc_html__( 'Galaxy Settings', 'wc-galaxy' ),
            esc_html__( 'Galaxy Settings', 'wc-galaxy' ),
            'manage_options',
            'galaxy-settings',
            array( $this, 'admin_setting_page' ),
            'dashicons-money-alt',
            NULL
        );
    }

    // Admin general setting page.
    public function admin_setting_page() {
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__( 'Galaxy Settings', 'wc-galaxy' ) . '</h1>';
        settings_errors();
        do_action( 'galaxy_admin_notifications' );
        echo '<hr>';
        $this->settings_api->show_navigation();
        $this->settings_api->show_forms();
        echo '</div>';
    }

} // End of GALAXY_Admin_Init class

// Init the class
$galaxy_admin_init = new GALAXY_Admin_Init;