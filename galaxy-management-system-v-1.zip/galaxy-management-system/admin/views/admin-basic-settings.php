<?php
return apply_filters( 'galaxy_widget_text_settings', array(
    array(
        'title'     => __( 'Galaxy Source ID', 'wc-galaxy' ),
        'id'        => 'galaxy_source_id',
        'type'      => 'text',
        'class'     => 'regular-text',
    ),

    array(
        'title'     => __( 'Galaxy Customer ID', 'wc-galaxy' ),
        'id'        => 'galaxy_customer_id',
        'type'      => 'text',
        'class'     => 'regular-text',
    ),


    array(
        'title'     => __( 'Galaxy Sales Program', 'wc-galaxy' ),
        'id'        => 'galaxy_sales_program',
        'type'      => 'text',
        'class'     => 'regular-text',
    ),

) );
?>