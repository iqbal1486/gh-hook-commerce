<?php
/*
* Plugin Name: Galaxy Management System
* Description: This plugin is used to push the Tour Booking Data to the Galaxy System
* Plugin URI:  http://www.geekerhub.com/
* Author:      NisarAhmed Momin
* Author URI:  http://www.geekerhub.com/
* Version:     1.0.0
* License:     GPL2
* License URI: https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain: wc-galaxy
* Domain Path: languages
*/

// Preventing to direct access
defined( 'ABSPATH' ) OR die( 'Direct access not acceptable!' );

/**
 * Plugin file.
 * 
 */
if ( ! defined( 'GALAXY_PLUGIN_FILE' ) ) {
    define( 'GALAXY_PLUGIN_FILE', __FILE__ );
}

/**
 * Defined Plugin ABSPATH
 * 
 */
if ( ! defined( 'GALAXY_PLUGIN_PATH' ) ) {
    define( 'GALAXY_PLUGIN_PATH', plugin_dir_path( GALAXY_PLUGIN_FILE ) );
}

/**
 * Defined Plugin URL
 * 
 */
if ( ! defined( 'GALAXY_PLUGIN_URL' ) ) {
    define( 'GALAXY_PLUGIN_URL', plugin_dir_url( GALAXY_PLUGIN_FILE ) );
}


/**
 * Defined plugin version
 * 
 */
if ( ! defined( 'GALAXY_PLUGIN_VER' ) ) {
    define( 'GALAXY_PLUGIN_VER', '1.0.0' );
}

/**
 * Define GALAXY API URL
 * 
 */
if ( ! defined( 'GALAXY_API_URL' ) ) {
    define( 'GALAXY_API_URL', "http://5.32.84.74:3051" );
}

/**
 * Define GALAXY SOURCE ID
 * 
 */
if ( ! defined( 'GALAXY_SOURCEID' ) ) {
    define( 'GALAXY_SOURCEID', get_option('galaxy_source_id') );
}

/**
 * Define GALAXY MESSAGE ID
 * 
 */
if ( ! defined( 'GALAXY_MESSAGEID' ) ) {
    //define( 'GALAXY_MESSAGEID', get_option('galaxy_message_id') );
    define( 'GALAXY_MESSAGEID', '1' );
}

/**
 * Define GALAXY MESSAGE TYPE
 * 
 */
if ( ! defined( 'GALAXY_MESSAGETYPE' ) ) {
    //define( 'GALAXY_MESSAGETYPE', get_option('galaxy_message_type') );
    define( 'GALAXY_MESSAGETYPE', 'ORDERS' );
}


/**
 * Define GALAXY CUSTOMER ID
 * 
 */
if ( ! defined( 'GALAXY_CUSTOMERID' ) ) {
    define( 'GALAXY_CUSTOMERID', get_option('galaxy_customer_id') );
}

/**
 * Define GALAXY SALESPROGRAM
 * 
 */
if ( ! defined( 'GALAXY_SALESPROGRAM' ) ) {
    define( 'GALAXY_SALESPROGRAM', get_option('galaxy_sales_program') );
}

/**
 * Define GALAXY ORDER STATUS
 * 
 */
if ( ! defined( 'GALAXY_ORDERSTATUS' ) ) {
    //define( 'GALAXY_ORDERSTATUS', get_option('galaxy_order_status') );
    define( 'GALAXY_ORDERSTATUS', '3' );
}

/**
 * Define GALAXY DETAIL TYPE
 * 
 */
if ( ! defined( 'GALAXY_DETAILTYPE' ) ) {
    //define( 'GALAXY_DETAILTYPE', get_option('galaxy_detail_type') );
    define( 'GALAXY_DETAILTYPE', '2' );
}


/**
 * Define GALAXY PAYMENTCODE
 * 
 */
if ( ! defined( 'GALAXY_PAYMENTCODE' ) ) {
    //define( 'GALAXY_PAYMENTCODE', get_option('galaxy_payment_code') );
    define( 'GALAXY_PAYMENTCODE', '21' );
}


/**
 * Define GALAXY AUTH CODE
 * 
 */
if ( ! defined( 'GALAXY_AUTHCODE' ) ) {
    //define( 'GALAXY_AUTHCODE', get_option('galaxy_authcode') );
    define( 'GALAXY_AUTHCODE', '123456' );
}


// Load plugin with plugins_load
function galaxy_init() {
    require_once GALAXY_PLUGIN_PATH . 'class-galaxy-init.php';
    
    $galaxy_init = new GALAXY_Init;
    $galaxy_init->init();
}
add_action( 'plugins_loaded', 'galaxy_init', 20 );


function galaxy_add_new_column_to_tournament_order_table(){
    global $table_prefix, $wpdb;
    /** 
     * Snippet Name: Alter WordPress sql tables: add a new column 
     * galaxy_api_status will have two values "pending" and "success"
     */  
    $table_name                 = 'tourmaster_order';
    $wp_tourmaster_order        = $table_prefix . "$table_name";
    $row = $wpdb->get_results(  "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '".$wp_tourmaster_order."' AND column_name = 'galaxy_api_status'"  );  
  
    if(empty($row)){
       $wpdb->query("ALTER TABLE $wp_tourmaster_order ADD galaxy_api_status varchar(10) NOT NULL DEFAULT 'pending'");  
    }
}
register_activation_hook( __FILE__, 'galaxy_add_new_column_to_tournament_order_table' );    
?>