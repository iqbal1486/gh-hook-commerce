<?php

// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

/**
 * GALAXY_Enqueue_Scripts class responsable to load all the scripts and styles.
 */
class GALAXY_Enqueue_Scripts {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'public_enqueue_scripts' ), 10);
    }

    public function public_enqueue_scripts() {

        wp_enqueue_script( 'galaxy-public-script', GALAXY_PLUGIN_URL . '/assets/js/galaxy-public-script.js', array('jquery'), GALAXY_PLUGIN_VER );
        wp_localize_script( 'galaxy-public-script', 'galaxyObj', array(
            'plugin_url'            => esc_url( GALAXY_PLUGIN_URL ),
            'is_mobile'             => ( wp_is_mobile() ) ? '1' : '0',
            'current_page_id'       => get_the_ID(),
            'current_page_url'      => get_permalink(),
            'ajax_url'              => admin_url( 'admin-ajax.php?ver=' . uniqid() ),
            'version'               => GALAXY_PLUGIN_VER,
        ) );

       wp_enqueue_style( 'galaxy-public-style', GALAXY_PLUGIN_URL . 'assets/css/galaxy-public-style.css', array(), GALAXY_PLUGIN_VER );
        
    }
    
} // end of class GALAXY_Enqueue_Scripts

$galaxy_enqueue_scripts = new GALAXY_Enqueue_Scripts;